<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[
    'uses' => 'vegefoodController@index',
    'as' => '/'

]);
Route::get('blog',[
    'uses' => 'vegefoodController@blog',
    'as' => 'blog'

]);
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::get('/food/add',[
    'uses' => 'FoodController@index',
    'as' => 'add-food'

]);
Route::post('/food/save',[
    'uses' => 'FoodController@saveFood',
    'as' => 'new-food'

]);
Route::get('/food/manage',[
    'uses' => 'FoodController@manageFood',
    'as' => 'manage-food'

]);
Route::get('/food/notavailable/{id}',[
    'uses' => 'FoodController@notavailableFood',
    'as' => 'notavailable-food'

]);
Route::get('/food/available/{id}',[
    'uses' => 'FoodController@availableFood',
    'as' => 'available-food'

]);
Route::get('/food/edit/{id}',[
    'uses' => 'FoodController@editFood',
    'as' => 'edit-food'

]);
Route::post('/food/update',[
    'uses' => 'FoodController@updateFood',
    'as' => 'update-food'

]);
Route::get('/food/delete/{id}',[
    'uses' => 'FoodController@deleteFood',
    'as' => 'delete-food'

]);
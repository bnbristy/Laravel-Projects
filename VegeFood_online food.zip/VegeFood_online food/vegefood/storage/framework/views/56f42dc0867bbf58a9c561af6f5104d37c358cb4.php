<?php $__env->startSection('title'); ?>
    vegefood || managefood
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <?php if(Session::get('message')): ?>
                            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                <h3 class="text-center text-success"><?php echo e(Session::get('message')); ?></h3>
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                        <?php else: ?>
                        <?php endif; ?>
                        <h5 class="card-title">Basic Datatable</h5>
                        <div class="table-responsive">
                            <table id="zero_config" class="table table-striped table-bordered">
                                <thead>
                                <tr>
                                    <th>Sl</th>
                                    <th>Food Name</th>
                                    <th>Food Description</th>
                                    <th>Available Status</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php ($i=1); ?>;
                                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i++); ?></td>
                                        <td><?php echo e($menu->food_name); ?></td>
                                        <td><?php echo e($menu->food_description); ?></td>
                                        <td><?php echo e($menu->available_status ==1? 'available' : 'not available'); ?></td>
                                        <td>
                                            <?php if($menu->available_status ==1): ?>
                                                <a href="<?php echo e(route('notavailable-food',['id' => $menu->id])); ?>" class="btn-btn-primary">
                                                    <span><i class="fa fa-arrow-up"></i></span>
                                                </a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('available-food',['id' => $menu->id])); ?>" class="btn-btn-warning">
                                                    <span><i class="fa fa-arrow-down"></i></span>
                                                </a>
                                            <?php endif; ?>
                                            <a href="<?php echo e(route('edit-food',['id' => $menu->id])); ?>" class="btn-btn-success">
                                                <span><i class="fa fa-edit"></i></span>
                                            </a>
                                            <a href="<?php echo e(route('delete-food',['id' => $menu->id])); ?>" class="btn-btn-danger">
                                                <span><i class="fa fa-trash"></i></span>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot>
                                <tr>
                                    <th>Sl</th>
                                    <th>Food Name</th>
                                    <th>Food Description</th>
                                    <th>Available Status</th>
                                    <th>Action</th>
                                </tr>
                                </tfoot>
                            </table>
                        </div>

                    </div>
                </div>
            </div>

        </div>

    </div>
    <script>
        /****************************************
         *       Basic Table                   *
         ****************************************/
        $('#zero_config').DataTable();
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Bristy\htdocs\vegefood\resources\views/admin/menu/manage-food.blade.php ENDPATH**/ ?>
<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class menu extends Model
{
    protected $fillable = [
        'food_name', 'food_description', 'available_status',
    ];
}

<?php

namespace App\Http\Controllers;
use App\Menu;
use Illuminate\Http\Request;

class FoodController extends Controller
{
    public function index(){
      return view('admin.menu.add-food');
    }
    public function saveFood(Request $request){
        $menu = new Menu();
        $menu->food_name = $request->food_name;
        $menu->food_description = $request->food_description;
        $menu->available_status = $request->available_status;
        $menu->save();

        return redirect ('/food/add')->with('message','food added successfully');
    }
    public function manageFood(){
        $menus = Menu::all();
        return view ('admin.menu.manage-food',[
        'menus' => $menus
        ]);
    }
    public function notavailableFood($id){
        $menu = Menu::find($id);
        $menu->available_status = 0;
        $menu->save();

        return redirect('/food/manage');

    }
    public function availableFood($id){
        $menu = Menu::find($id);
        $menu->available_status = 1;
        $menu->save();

        return redirect('/food/manage');

    }
    public function editFood($id){
        $menu = Menu::find($id);
        return view('admin.menu.edit-food',[
        'menu' => $menu
    ]);
    }
    public function updateFood(Request $request){
        $menu = Menu::find($request->id);
        $menu->food_name = $request->food_name;
        $menu->food_description = $request->food_description;
        $menu->available_status = $request->available_status;
        $menu->save();
        return redirect ('/food/manage')->with ('message','food updated successfully');
    }
    public function deleteFood($id){
        $menu = Menu::find($id);
        $menu->delete();
        return redirect('/food/manage')->with ('message','food deleted successfully');
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class vegefoodController extends Controller
{
    public function index(){
        return view('front-end.home.home');
    }
    public function blog(){
        return view('front-end.blog.blog');
    }
}
